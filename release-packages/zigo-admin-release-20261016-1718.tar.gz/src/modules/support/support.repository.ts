import { randomInt } from "node:crypto";
import type { PoolClient } from "pg";
import { pool } from "../../db/pool.js";
import { HttpError } from "../../http/errors.js";

type Queryable = Pick<typeof pool, "query">;

export type SupportActor = "customer" | "assistant" | "admin" | "system";
export type SupportAttachment = { url: string; name?: string; type?: string; size?: number };

let assistantSupportSchemaReady: Promise<void> | null = null;

function ensureAssistantSupportSchema() {
  if (assistantSupportSchemaReady) return assistantSupportSchemaReady;
  assistantSupportSchemaReady = pool.query(`
    create table if not exists zigo.assistant_support_tickets (
      id uuid primary key default gen_random_uuid(),
      ticket_number varchar(32) not null unique,
      assistant_id uuid not null references zigo.assistants(id),
      booking_id uuid references zigo.service_requests(id) on delete set null,
      task_assignment_id uuid references zigo.task_assignments(id) on delete set null,
      subject varchar(200) not null,
      category varchar(60) not null default 'task_help',
      status_code varchar(30) not null default 'open',
      priority_code varchar(20) not null default 'normal',
      assigned_admin_user_id uuid references zigo.users(id),
      last_message_at timestamptz not null default now(),
      closed_at timestamptz,
      metadata jsonb not null default '{}'::jsonb,
      created_at timestamptz not null default now(),
      updated_at timestamptz not null default now()
    );
    create table if not exists zigo.assistant_support_messages (
      id uuid primary key default gen_random_uuid(),
      ticket_id uuid not null references zigo.assistant_support_tickets(id) on delete cascade,
      sender_type varchar(20) not null,
      sender_user_id uuid references zigo.users(id),
      message text not null,
      metadata jsonb not null default '{}'::jsonb,
      created_at timestamptz not null default now()
    );
    create index if not exists idx_assistant_support_tickets_assistant
      on zigo.assistant_support_tickets (assistant_id, last_message_at desc);
    create index if not exists idx_assistant_support_tickets_status
      on zigo.assistant_support_tickets (status_code, priority_code, last_message_at desc);
    create index if not exists idx_assistant_support_messages_ticket
      on zigo.assistant_support_messages (ticket_id, created_at);
  `).then(() => undefined).catch((error) => {
    assistantSupportSchemaReady = null;
    throw error;
  });
  return assistantSupportSchemaReady;
}

function ticketNumber(now = new Date()) {
  const parts = [
    String(now.getFullYear()).slice(-2),
    String(now.getMonth() + 1).padStart(2, "0"),
    String(now.getDate()).padStart(2, "0"),
    String(now.getHours()).padStart(2, "0"),
    String(now.getMinutes()).padStart(2, "0")
  ].join("");
  return `TKZUI${parts}${String(randomInt(0, 100_000_000)).padStart(8, "0")}`;
}

function assistantTicketNumber(now = new Date()) {
  return ticketNumber(now).replace(/^TKZUI/, "ATZUI");
}

async function customerIdForUser(userId: string, client: Queryable = pool) {
  const result = await client.query<{ id: string }>(
    "select id from zigo.customers where user_id = $1::uuid limit 1",
    [userId]
  );
  if (!result.rows[0]) throw new HttpError(404, "Customer profile not found.");
  return result.rows[0].id;
}

function normalizePage(page = 1, pageSize = 20) {
  return {
    page: Math.max(1, Math.trunc(page)),
    pageSize: Math.max(5, Math.min(100, Math.trunc(pageSize)))
  };
}

const ticketSelect = `
  select t.id,
    t.ticket_number as "ticketNumber",
    t.customer_id as "customerId",
    t.booking_id as "bookingId",
    sr.request_number as "bookingNumber",
    t.subject,
    t.category,
    t.status_code as "statusCode",
    t.priority_code as "priorityCode",
    t.assigned_admin_user_id as "assignedAdminUserId",
    au.display_name as "assignedAdminName",
    cu.user_id as "customerUserId",
    u.display_name as "customerName",
    u.phone as "customerPhone",
    coalesce(lm.created_at, t.last_message_at, t.created_at) as "lastMessageAt",
    t.closed_at as "closedAt",
    t.metadata,
    t.created_at as "createdAt",
    t.updated_at as "updatedAt",
    lm.message as "lastMessage",
    (select count(*)::int from zigo.customer_support_messages m where m.ticket_id = t.id) as "messageCount"
  from zigo.customer_support_tickets t
  join zigo.customers cu on cu.id = t.customer_id
  join zigo.users u on u.id = cu.user_id
  left join zigo.users au on au.id = t.assigned_admin_user_id
  left join zigo.service_requests sr on sr.id = t.booking_id
  left join lateral (
    select m.message, m.created_at
    from zigo.customer_support_messages m
    where m.ticket_id = t.id
    order by m.created_at desc, m.id desc
    limit 1
  ) lm on true
`;

async function getTicket(ticketId: string, customerUserId?: string, client: Queryable = pool) {
  const params: unknown[] = [ticketId];
  let ownership = "";
  if (customerUserId) {
    params.push(customerUserId);
    ownership = `and cu.user_id = $${params.length}::uuid`;
  }
  const result = await client.query(`${ticketSelect} where t.id = $1::uuid ${ownership} limit 1`, params);
  if (!result.rows[0]) throw new HttpError(404, "Support ticket not found.");
  return result.rows[0];
}

async function listMessages(ticketId: string, client: Queryable = pool) {
  const result = await client.query(
    `select m.id,
       m.ticket_id as "ticketId",
       m.sender_type as "senderType",
       m.sender_user_id as "senderUserId",
       coalesce(u.display_name, case when m.sender_type = 'system' then 'ZIGO Support' else initcap(m.sender_type) end) as "senderName",
       m.message,
       m.metadata,
       m.created_at as "createdAt"
     from zigo.customer_support_messages m
     left join zigo.users u on u.id = m.sender_user_id
     where m.ticket_id = $1::uuid
     order by m.created_at asc, m.id asc`,
    [ticketId]
  );
  return result.rows;
}

export async function listCustomerSupportTickets(userId: string, input: { page?: number; pageSize?: number; bookingId?: string }) {
  const customerId = await customerIdForUser(userId);
  const { page, pageSize } = normalizePage(input.page, input.pageSize);
  const params: unknown[] = [customerId];
  const conditions = ["t.customer_id = $1::uuid"];
  if (input.bookingId) {
    params.push(input.bookingId);
    conditions.push(`t.booking_id = $${params.length}::uuid`);
  }
  const where = `where ${conditions.join(" and ")}`;
  const count = await pool.query<{ total: number }>(
    `select count(*)::int as total from zigo.customer_support_tickets t ${where}`,
    params
  );
  params.push(pageSize, (page - 1) * pageSize);
  const rows = await pool.query(
    `${ticketSelect} ${where}
     order by coalesce(lm.created_at, t.last_message_at, t.created_at) desc, t.created_at desc, t.id desc
     limit $${params.length - 1} offset $${params.length}`,
    params
  );
  const total = Number(count.rows[0]?.total || 0);
  return { rows: rows.rows, pagination: { page, pageSize, totalRecords: total, totalPages: Math.max(1, Math.ceil(total / pageSize)) } };
}

export async function getCustomerSupportTicket(userId: string, ticketId: string) {
  const ticket = await getTicket(ticketId, userId);
  return { ticket, messages: await listMessages(ticketId) };
}

async function insertUniqueTicket(client: PoolClient, input: { customerId: string; bookingId?: string | null; subject: string; category: string; metadata?: Record<string, unknown> }) {
  for (let attempt = 0; attempt < 5; attempt += 1) {
    try {
      const result = await client.query<{ id: string }>(
        `insert into zigo.customer_support_tickets
          (ticket_number, customer_id, booking_id, subject, category, metadata)
         values ($1, $2::uuid, $3::uuid, $4, $5, $6::jsonb)
         returning id`,
        [ticketNumber(), input.customerId, input.bookingId || null, input.subject, input.category, JSON.stringify(input.metadata || {})]
      );
      return result.rows[0].id;
    } catch (error) {
      if ((error as { code?: string }).code !== "23505" || attempt === 4) throw error;
    }
  }
  throw new HttpError(500, "Unable to generate a unique ticket number.");
}

export async function createCustomerSupportTicket(userId: string, input: { subject: string; category: string; message: string; bookingId?: string | null }) {
  const client = await pool.connect();
  try {
    await client.query("begin");
    const customerId = await customerIdForUser(userId, client);
    const message = input.message.trim();
    if (input.bookingId) {
      const booking = await client.query(
        `select 1 from zigo.service_requests sr join zigo.customers c on c.id = sr.customer_id
         where sr.id = $1::uuid and c.user_id = $2::uuid`,
        [input.bookingId, userId]
      );
      if (!booking.rows[0]) throw new HttpError(400, "Selected booking does not belong to this customer.");
    }
    const conversationKey = `${customerId}:${input.bookingId || `${input.category}:${input.subject.trim().toLowerCase()}`}`;
    await client.query("select pg_advisory_xact_lock(hashtext($1))", [conversationKey]);
    const existing = await client.query<{ id: string }>(
      `select t.id
       from zigo.customer_support_tickets t
       where t.customer_id = $1::uuid
         and t.status_code not in ('closed', 'resolved')
         and (
           ($2::uuid is not null and t.booking_id = $2::uuid)
           or
           ($2::uuid is null and t.booking_id is null and t.category = $3 and lower(t.subject) = lower($4))
         )
       order by coalesce(t.last_message_at, t.created_at) desc, t.created_at desc
       limit 1`,
      [customerId, input.bookingId || null, input.category, input.subject]
    );
    if (existing.rows[0]) {
      const existingId = existing.rows[0].id;
      if (message) {
        await client.query(
          `with inserted_message as (
             insert into zigo.customer_support_messages (ticket_id, sender_type, sender_user_id, message)
             values ($1::uuid, 'customer', $2::uuid, $3)
             returning created_at
           )
           update zigo.customer_support_tickets
           set status_code = case when status_code = 'waiting_customer' then 'open' else status_code end,
               last_message_at = (select created_at from inserted_message), updated_at = now()
           where id = $1::uuid`,
          [existingId, userId, message]
        );
      }
      await client.query("commit");
      return { ...(await getCustomerSupportTicket(userId, existingId)), created: false, messageAdded: Boolean(message) };
    }
    const id = await insertUniqueTicket(client, { customerId, bookingId: input.bookingId, subject: input.subject, category: input.category });
    if (message) {
      await client.query(
        `with inserted_message as (
           insert into zigo.customer_support_messages (ticket_id, sender_type, sender_user_id, message)
           values ($1::uuid, 'customer', $2::uuid, $3)
           returning created_at
         )
         update zigo.customer_support_tickets
         set last_message_at = (select created_at from inserted_message), updated_at = now()
         where id = $1::uuid`,
        [id, userId, message]
      );
    }
    await client.query("commit");
    return { ...(await getCustomerSupportTicket(userId, id)), created: true, messageAdded: Boolean(message) };
  } catch (error) {
    await client.query("rollback");
    throw error;
  } finally {
    client.release();
  }
}

export async function addCustomerSupportMessage(userId: string, ticketId: string, input: { message: string; attachments?: SupportAttachment[] }) {
  const ticket = await getTicket(ticketId, userId);
  if (["closed", "resolved"].includes(String(ticket.statusCode))) throw new HttpError(409, "This ticket is closed.");
  const attachments = input.attachments || [];
  await pool.query(
    `with inserted_message as (
       insert into zigo.customer_support_messages (ticket_id, sender_type, sender_user_id, message, metadata)
       values ($1::uuid, 'customer', $2::uuid, $3, $4::jsonb)
       returning ticket_id
     )
     update zigo.customer_support_tickets
     set status_code = case when status_code = 'waiting_customer' then 'open' else status_code end,
         last_message_at = now(), updated_at = now()
     where id = (select ticket_id from inserted_message)`,
    [ticketId, userId, input.message, JSON.stringify({ attachments })]
  );
  return getCustomerSupportTicket(userId, ticketId);
}

export async function listAdminSupportTickets(input: { search?: string; status?: string; page?: number; pageSize?: number }) {
  const { page, pageSize } = normalizePage(input.page, input.pageSize);
  const params: unknown[] = [];
  const conditions: string[] = [];
  const search = String(input.search || "").trim();
  const status = String(input.status || "all").trim().toLowerCase();
  if (status && status !== "all") { params.push(status); conditions.push(`t.status_code = $${params.length}`); }
  if (search) {
    params.push(`%${search}%`);
    conditions.push(`(t.ticket_number ilike $${params.length} or t.subject ilike $${params.length} or u.display_name ilike $${params.length} or u.phone ilike $${params.length})`);
  }
  const where = conditions.length ? `where ${conditions.join(" and ")}` : "";
  const count = await pool.query<{ total: number }>(
    `select count(*)::int as total from zigo.customer_support_tickets t join zigo.customers cu on cu.id=t.customer_id join zigo.users u on u.id=cu.user_id ${where}`,
    params
  );
  params.push(pageSize, (page - 1) * pageSize);
  const rows = await pool.query(`${ticketSelect} ${where}
    order by case t.priority_code when 'urgent' then 1 when 'high' then 2 else 3 end,
      coalesce(lm.created_at, t.last_message_at, t.created_at) desc, t.created_at desc, t.id desc
    limit $${params.length - 1} offset $${params.length}`, params);
  const total = Number(count.rows[0]?.total || 0);
  return { rows: rows.rows, pagination: { page, pageSize, totalRecords: total, totalPages: Math.max(1, Math.ceil(total / pageSize)) } };
}

export async function getAdminSupportTicket(ticketId: string) {
  return { ticket: await getTicket(ticketId), messages: await listMessages(ticketId) };
}

export async function addAdminSupportMessage(adminUserId: string, ticketId: string, message: string) {
  await getTicket(ticketId);
  await pool.query(
    `with inserted_message as (
       insert into zigo.customer_support_messages (ticket_id, sender_type, sender_user_id, message)
       values ($1::uuid, 'admin', $2::uuid, $3)
       returning ticket_id
     )
     update zigo.customer_support_tickets
     set assigned_admin_user_id = coalesce(assigned_admin_user_id, $2::uuid), status_code = 'waiting_customer',
         last_message_at = now(), updated_at = now()
     where id = (select ticket_id from inserted_message)`,
    [ticketId, adminUserId, message]
  );
  return getAdminSupportTicket(ticketId);
}

export async function updateAdminSupportTicket(adminUserId: string, ticketId: string, input: { statusCode?: string; priorityCode?: string; assignToMe?: boolean }) {
  await getTicket(ticketId);
  const result = await pool.query(
    `update zigo.customer_support_tickets
     set status_code = coalesce($2, status_code),
         priority_code = coalesce($3, priority_code),
         assigned_admin_user_id = case when $4::boolean then $1::uuid else assigned_admin_user_id end,
         closed_at = case when coalesce($2, status_code) in ('closed','resolved') then coalesce(closed_at, now()) else null end,
         updated_at = now()
     where id = $5::uuid
     returning id`,
    [adminUserId, input.statusCode || null, input.priorityCode || null, Boolean(input.assignToMe), ticketId]
  );
  if (!result.rows[0]) throw new HttpError(404, "Support ticket not found.");
  return getAdminSupportTicket(ticketId);
}

async function assistantIdForUser(userId: string, client: Queryable = pool) {
  const result = await client.query<{ id: string }>(
    "select id from zigo.assistants where user_id = $1::uuid limit 1",
    [userId]
  );
  if (!result.rows[0]) throw new HttpError(404, "Assistant profile not found.");
  return result.rows[0].id;
}

const assistantTicketSelect = `
  select t.id,
    t.ticket_number as "ticketNumber",
    t.assistant_id as "assistantId",
    t.booking_id as "bookingId",
    t.task_assignment_id as "assignmentId",
    sr.request_number as "bookingNumber",
    t.subject,
    t.category,
    t.status_code as "statusCode",
    t.priority_code as "priorityCode",
    t.assigned_admin_user_id as "assignedAdminUserId",
    au.display_name as "assignedAdminName",
    a.user_id as "assistantUserId",
    u.display_name as "assistantName",
    u.phone as "assistantPhone",
    u.metadata->>'profilePictureUrl' as "assistantProfilePictureUrl",
    coalesce(lm.created_at, t.last_message_at, t.created_at) as "lastMessageAt",
    t.closed_at as "closedAt",
    t.metadata,
    t.created_at as "createdAt",
    t.updated_at as "updatedAt",
    lm.message as "lastMessage",
    (select count(*)::int from zigo.assistant_support_messages m where m.ticket_id = t.id) as "messageCount"
  from zigo.assistant_support_tickets t
  join zigo.assistants a on a.id = t.assistant_id
  join zigo.users u on u.id = a.user_id
  left join zigo.users au on au.id = t.assigned_admin_user_id
  left join zigo.service_requests sr on sr.id = t.booking_id
  left join lateral (
    select m.message, m.created_at
    from zigo.assistant_support_messages m
    where m.ticket_id = t.id
    order by m.created_at desc, m.id desc
    limit 1
  ) lm on true
`;

async function getAssistantTicket(ticketId: string, assistantUserId?: string, client: Queryable = pool) {
  await ensureAssistantSupportSchema();
  const params: unknown[] = [ticketId];
  let ownership = "";
  if (assistantUserId) {
    params.push(assistantUserId);
    ownership = `and a.user_id = $${params.length}::uuid`;
  }
  const result = await client.query(`${assistantTicketSelect} where t.id = $1::uuid ${ownership} limit 1`, params);
  if (!result.rows[0]) throw new HttpError(404, "Assistant support chat not found.");
  return result.rows[0];
}

async function listAssistantSupportMessages(ticketId: string, client: Queryable = pool) {
  const result = await client.query(
    `select m.id,
       m.ticket_id as "ticketId",
       m.sender_type as "senderType",
       m.sender_user_id as "senderUserId",
       coalesce(u.display_name, case when m.sender_type = 'system' then 'ZIGO Support' else initcap(m.sender_type) end) as "senderName",
       m.message,
       m.metadata,
       m.created_at as "createdAt"
     from zigo.assistant_support_messages m
     left join zigo.users u on u.id = m.sender_user_id
     where m.ticket_id = $1::uuid
     order by m.created_at asc, m.id asc`,
    [ticketId]
  );
  return result.rows;
}

export async function getAssistantSupportTicket(userId: string, ticketId: string) {
  const ticket = await getAssistantTicket(ticketId, userId);
  return { ticket, messages: await listAssistantSupportMessages(ticketId) };
}

export async function createAssistantSupportTicket(userId: string, input: { assignmentId: string; message?: string }) {
  await ensureAssistantSupportSchema();
  const client = await pool.connect();
  try {
    await client.query("begin");
    const assistantId = await assistantIdForUser(userId, client);
    const assignment = await client.query<{ bookingId: string; bookingNumber: string | null }>(
      `select sr.id as "bookingId", sr.request_number as "bookingNumber"
       from zigo.task_assignments ta
       join zigo.service_requests sr on sr.id = coalesce(ta.service_request_id, ta.request_id)
       where ta.id = $1::uuid and ta.assistant_id = $2::uuid
       limit 1`,
      [input.assignmentId, assistantId]
    );
    if (!assignment.rows[0]) throw new HttpError(404, "Task not found for this assistant.");
    const bookingId = assignment.rows[0].bookingId;
    const bookingNumber = assignment.rows[0].bookingNumber || bookingId;
    await client.query("select pg_advisory_xact_lock(hashtext($1))", [`assistant-support:${assistantId}:${input.assignmentId}`]);
    const existing = await client.query<{ id: string }>(
      `select id
       from zigo.assistant_support_tickets
       where assistant_id = $1::uuid and task_assignment_id = $2::uuid
         and status_code not in ('closed', 'resolved')
       order by coalesce(last_message_at, created_at) desc
       limit 1`,
      [assistantId, input.assignmentId]
    );
    let ticketId = existing.rows[0]?.id || "";
    let created = false;
    if (!ticketId) {
      for (let attempt = 0; attempt < 5; attempt += 1) {
        try {
          const inserted = await client.query<{ id: string }>(
            `insert into zigo.assistant_support_tickets
              (ticket_number, assistant_id, booking_id, task_assignment_id, subject, category, metadata)
             values ($1, $2::uuid, $3::uuid, $4::uuid, $5, 'task_help', $6::jsonb)
             returning id`,
            [assistantTicketNumber(), assistantId, bookingId, input.assignmentId, `Help with booking ${bookingNumber}`, JSON.stringify({ source: "assistant_task_help" })]
          );
          ticketId = inserted.rows[0].id;
          created = true;
          break;
        } catch (error) {
          if ((error as { code?: string }).code !== "23505" || attempt === 4) throw error;
        }
      }
    }
    if (!ticketId) throw new HttpError(500, "Unable to start assistant support chat.");
    const message = String(input.message || "").trim();
    if (message) {
      await client.query(
        `with inserted_message as (
           insert into zigo.assistant_support_messages (ticket_id, sender_type, sender_user_id, message)
           values ($1::uuid, 'assistant', $2::uuid, $3)
           returning created_at
         )
         update zigo.assistant_support_tickets
         set status_code = case when status_code = 'waiting_assistant' then 'open' else status_code end,
             last_message_at = (select created_at from inserted_message), updated_at = now()
         where id = $1::uuid`,
        [ticketId, userId, message]
      );
    }
    await client.query("commit");
    return { ...(await getAssistantSupportTicket(userId, ticketId)), created, messageAdded: Boolean(message) };
  } catch (error) {
    await client.query("rollback");
    throw error;
  } finally {
    client.release();
  }
}

export async function addAssistantSupportMessage(userId: string, ticketId: string, input: { message: string; attachments?: SupportAttachment[] }) {
  const ticket = await getAssistantTicket(ticketId, userId);
  if (["closed", "resolved"].includes(String(ticket.statusCode))) throw new HttpError(409, "This support chat is closed.");
  const attachments = input.attachments || [];
  await pool.query(
    `with inserted_message as (
       insert into zigo.assistant_support_messages (ticket_id, sender_type, sender_user_id, message, metadata)
       values ($1::uuid, 'assistant', $2::uuid, $3, $4::jsonb)
       returning created_at
     )
     update zigo.assistant_support_tickets
     set status_code = case when status_code = 'waiting_assistant' then 'open' else status_code end,
         last_message_at = (select created_at from inserted_message), updated_at = now()
     where id = $1::uuid`,
    [ticketId, userId, input.message, JSON.stringify({ attachments })]
  );
  return getAssistantSupportTicket(userId, ticketId);
}

export async function listAdminAssistantSupportTickets(input: { search?: string; status?: string; page?: number; pageSize?: number }) {
  await ensureAssistantSupportSchema();
  const { page, pageSize } = normalizePage(input.page, input.pageSize);
  const params: unknown[] = [];
  const conditions: string[] = [];
  const search = String(input.search || "").trim();
  const status = String(input.status || "all").trim().toLowerCase();
  if (status && status !== "all") { params.push(status); conditions.push(`t.status_code = $${params.length}`); }
  if (search) {
    params.push(`%${search}%`);
    conditions.push(`(t.ticket_number ilike $${params.length} or t.subject ilike $${params.length} or u.display_name ilike $${params.length} or u.phone ilike $${params.length} or sr.request_number ilike $${params.length})`);
  }
  const where = conditions.length ? `where ${conditions.join(" and ")}` : "";
  const count = await pool.query<{ total: number }>(
    `select count(*)::int as total
     from zigo.assistant_support_tickets t
     join zigo.assistants a on a.id = t.assistant_id
     join zigo.users u on u.id = a.user_id
     left join zigo.service_requests sr on sr.id = t.booking_id
     ${where}`,
    params
  );
  params.push(pageSize, (page - 1) * pageSize);
  const rows = await pool.query(
    `${assistantTicketSelect} ${where}
     order by case t.priority_code when 'urgent' then 1 when 'high' then 2 else 3 end,
       coalesce(lm.created_at, t.last_message_at, t.created_at) desc, t.created_at desc, t.id desc
     limit $${params.length - 1} offset $${params.length}`,
    params
  );
  const total = Number(count.rows[0]?.total || 0);
  return { rows: rows.rows, pagination: { page, pageSize, totalRecords: total, totalPages: Math.max(1, Math.ceil(total / pageSize)) } };
}

export async function getAdminAssistantSupportTicket(ticketId: string) {
  return { ticket: await getAssistantTicket(ticketId), messages: await listAssistantSupportMessages(ticketId) };
}

export async function addAdminAssistantSupportMessage(adminUserId: string, ticketId: string, message: string) {
  await getAssistantTicket(ticketId);
  await pool.query(
    `with inserted_message as (
       insert into zigo.assistant_support_messages (ticket_id, sender_type, sender_user_id, message)
       values ($1::uuid, 'admin', $2::uuid, $3)
       returning created_at
     )
     update zigo.assistant_support_tickets
     set assigned_admin_user_id = coalesce(assigned_admin_user_id, $2::uuid), status_code = 'waiting_assistant',
         last_message_at = (select created_at from inserted_message), updated_at = now()
     where id = $1::uuid`,
    [ticketId, adminUserId, message]
  );
  return getAdminAssistantSupportTicket(ticketId);
}

export async function updateAdminAssistantSupportTicket(adminUserId: string, ticketId: string, input: { statusCode?: string; priorityCode?: string; assignToMe?: boolean }) {
  await getAssistantTicket(ticketId);
  const result = await pool.query(
    `update zigo.assistant_support_tickets
     set status_code = coalesce($2, status_code),
         priority_code = coalesce($3, priority_code),
         assigned_admin_user_id = case when $4::boolean then $1::uuid else assigned_admin_user_id end,
         closed_at = case when coalesce($2, status_code) in ('closed','resolved') then coalesce(closed_at, now()) else null end,
         updated_at = now()
     where id = $5::uuid
     returning id`,
    [adminUserId, input.statusCode || null, input.priorityCode || null, Boolean(input.assignToMe), ticketId]
  );
  if (!result.rows[0]) throw new HttpError(404, "Assistant support chat not found.");
  return getAdminAssistantSupportTicket(ticketId);
}
